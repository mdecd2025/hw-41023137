# pip install websocket-client websocket-server keyboard
import threading
import json
import socket
from websocket_server import WebsocketServer
from controller import Robot, Keyboard as WebotsKeyboard
import keyboard  # For capturing key presses

# Constants
TIME_STEP = 32  # Simulation time step in milliseconds
WHEEL_RADIUS = 0.1  # Radius of the wheels in meters (10cm)
L = 0.471  # Half of the robot's length in meters
W = 0.376  # Half of the robot's width in meters
MAX_VELOCITY = 10.0  # Maximum velocity allowed for the wheels

# Initialize the robot
robot = Robot()

# Initialize the Webots keyboard
webots_keyboard = WebotsKeyboard()
webots_keyboard.enable(TIME_STEP)

# Get motor devices
wheel1 = robot.getDevice("wheel1")  # Front-right wheel
wheel2 = robot.getDevice("wheel2")  # Front-left wheel
wheel3 = robot.getDevice("wheel3")  # Rear-right wheel
wheel4 = robot.getDevice("wheel4")  # Rear-left wheel

# Set motors to velocity control mode
for wheel in [wheel1, wheel2, wheel3, wheel4]:
    wheel.setPosition(float('inf'))  # Enable velocity control
    wheel.setVelocity(0)  # Set initial velocity to 0


def set_wheel_velocity(v1, v2, v3, v4):
    """Set the velocity of all wheels."""
    wheel1.setVelocity(v1)
    wheel2.setVelocity(v2)
    wheel3.setVelocity(v3)
    wheel4.setVelocity(v4)


# Custom WebSocket server class to support IPv6
class IPv6WebsocketServer(WebsocketServer):
    def __init__(self, host, port):
        self.address_family = socket.AF_INET6  # Enable IPv6
        super().__init__(host=host, port=port)


# WebSocket message handler
def on_message(client, server, message):
    """Handle incoming WebSocket messages to control the robot."""
    try:
        data = json.loads(message)  # Parse the message
        direction = data.get("direction")

        if direction == "UP":
            velocity = MAX_VELOCITY
            set_wheel_velocity(velocity, velocity, velocity, velocity)
        elif direction == "DOWN":
            velocity = -MAX_VELOCITY
            set_wheel_velocity(velocity, velocity, velocity, velocity)
        elif direction == "LEFT":
            velocity = MAX_VELOCITY
            set_wheel_velocity(-velocity, velocity, -velocity, velocity)
        elif direction == "RIGHT":
            velocity = MAX_VELOCITY
            set_wheel_velocity(velocity, -velocity, velocity, -velocity)
        elif direction == "STOP":
            set_wheel_velocity(0, 0, 0, 0)
    except json.JSONDecodeError:
        print("Invalid message received. Expected JSON format.")
    except Exception as e:
        print(f"Error handling message: {e}")


# WebSocket server thread
def start_websocket_server():
    """Start WebSocket server to receive control messages."""
    server_ip = "2001:288:6004:17:fff1:cd25:0000:a006"  # Replace with the Webots server's IPv6 address
    server_port = 8081  # Port to listen on

    try:
        server = IPv6WebsocketServer(host=server_ip, port=server_port)
        server.set_fn_message_received(on_message)
        print(f"WebSocket server started on [{server_ip}]:{server_port}, waiting for commands...")
        server.run_forever()
    except Exception as e:
        print(f"Failed to start WebSocket server: {e}")


# Arrow key control thread
def start_arrow_key_control():
    """Listen for arrow key presses to control the robot."""
    print("Use arrow keys to control the robot locally (UP, DOWN, LEFT, RIGHT). Press 'ESC' to quit.")
    while True:
        try:
            if keyboard.is_pressed("up"):
                print("Arrow Key: UP")
                set_wheel_velocity(MAX_VELOCITY, MAX_VELOCITY, MAX_VELOCITY, MAX_VELOCITY)
            elif keyboard.is_pressed("down"):
                print("Arrow Key: DOWN")
                set_wheel_velocity(-MAX_VELOCITY, -MAX_VELOCITY, -MAX_VELOCITY, -MAX_VELOCITY)
            elif keyboard.is_pressed("left"):
                print("Arrow Key: LEFT")
                set_wheel_velocity(-MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY)
            elif keyboard.is_pressed("right"):
                print("Arrow Key: RIGHT")
                set_wheel_velocity(MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY)
            elif keyboard.is_pressed("esc"):
                print("Exiting arrow key control...")
                set_wheel_velocity(0, 0, 0, 0)
                break
        except Exception as e:
            print(f"Error in arrow key control: {e}")
            break


# Webots simulation thread
def start_webots_simulation():
    """Run the Webots simulation loop."""
    try:
        while robot.step(TIME_STEP) != -1:
            pass  # Simulation step logic can be added here if needed
    except Exception as e:
        print(f"Simulation error: {e}")


# Main function
if __name__ == "__main__":
    # Create threads for Webots simulation, WebSocket server, and arrow key control
    websocket_thread = threading.Thread(target=start_websocket_server, daemon=True)
    simulation_thread = threading.Thread(target=start_webots_simulation, daemon=True)
    arrow_key_thread = threading.Thread(target=start_arrow_key_control, daemon=True)

    # Start the threads
    websocket_thread.start()
    simulation_thread.start()
    arrow_key_thread.start()

    # Keep the main thread alive
    try:
        while True:
            pass
    except KeyboardInterrupt:
        print("Shutting down gracefully...")